
public class Borrower {

}
